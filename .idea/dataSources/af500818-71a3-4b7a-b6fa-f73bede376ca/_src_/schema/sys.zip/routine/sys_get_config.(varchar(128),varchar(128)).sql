CREATE FUNCTION sys_get_config(in_variable_name VARCHAR(128), in_default_value VARCHAR(128))
  RETURNS VARCHAR(128)
  BEGIN DECLARE v_value VARCHAR(128) DEFAULT NULL;  SET v_value = (SELECT value FROM sys.sys_config WHERE variable = in_variable_name);  IF (v_value IS NULL) THEN SET v_value = in_default_value; END IF;  RETURN v_value; END;
